package com.coimbra.agendaporvoz;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** A local, no-account-login Android app: speech -> editable preview -> Google calendar. */
public final class MainActivity extends Activity {
    private static final int REQUEST_SPEECH = 101;
    private static final int REQUEST_CALENDAR_PERMISSION = 102;
    private static final int GREEN = Color.rgb(22, 120, 85);
    private static final int BG = Color.rgb(247, 249, 247);
    private static final int DARK = Color.rgb(31, 45, 38);
    private static final int SUBTLE = Color.rgb(93, 111, 99);
    private static final int STROKE = Color.rgb(219, 231, 222);

    private Spinner languageSpinner;
    private Spinner durationSpinner;
    private Spinner reminderSpinner;
    private Spinner calendarSpinner;
    private EditText transcriptEdit;
    private EditText titleEdit;
    private EditText descriptionEdit;
    private TextView noticeText;
    private TextView calendarNotice;
    private Button dateButton;
    private Button timeButton;
    private Button saveButton;
    private Button grantButton;
    private LinearLayout previewPanel;
    private LinearLayout calendarAccessPanel;
    private EventParser.Draft draft;
    private LocalDate chosenDate;
    private LocalTime chosenTime;
    private boolean dateConfirmed;
    private boolean timeConfirmed;
    private final List<CalendarChoice> googleCalendars = new ArrayList<>();
    private final List<Integer> durationOptions = new ArrayList<>();
    private final List<Integer> reminderOptions = new ArrayList<>();

    private static final class CalendarChoice {
        final long id;
        final String label;
        final boolean primary;
        CalendarChoice(long id, String label, boolean primary) {
            this.id = id; this.label = label; this.primary = primary;
        }
        @Override public String toString() { return label; }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        refreshCalendars();
    }

    private int dp(int n) { return Math.round(getResources().getDisplayMetrics().density * n); }
    private GradientDrawable rounded(int color, int radiusDp, int borderColor) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(radiusDp));
        if (borderColor != 0) gd.setStroke(dp(1), borderColor);
        return gd;
    }
    private LinearLayout vertical() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }
    private void marginAdd(LinearLayout parent, View view, int bottomDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(bottomDp);
        parent.addView(view, lp);
    }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setLineSpacing(dp(2), 1f);
        return v;
    }
    private Button button(String value, boolean primary) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? Color.WHITE : GREEN);
        b.setBackground(rounded(primary ? GREEN : Color.WHITE, 14, primary ? 0 : STROKE));
        b.setMinHeight(dp(54));
        b.setPadding(dp(14), dp(12), dp(14), dp(12));
        return b;
    }
    private EditText edit(String hint, int lines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(16);
        e.setTextColor(DARK);
        e.setHintTextColor(SUBTLE);
        e.setBackground(rounded(Color.WHITE, 12, STROKE));
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setMinHeight(dp(lines == 1 ? 51 : 80));
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES |
                (lines > 1 ? InputType.TYPE_TEXT_FLAG_MULTI_LINE : 0));
        e.setSingleLine(lines == 1);
        return e;
    }
    private Spinner spinner() {
        Spinner v = new Spinner(this);
        v.setBackground(rounded(Color.WHITE, 12, STROKE));
        v.setPadding(dp(12), dp(12), dp(12), dp(12));
        v.setMinimumHeight(dp(52));
        return v;
    }
    private void label(LinearLayout parent, String value) {
        marginAdd(parent, text(value, 13, SUBTLE, true), 5);
    }
    private void setSpinnerOptions(Spinner v, List<String> labels) {
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        v.setAdapter(a);
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = vertical();
        root.setPadding(dp(20), dp(22), dp(20), dp(30));
        scroll.addView(root);
        setContentView(scroll);
        if (Build.VERSION.SDK_INT >= 30) {
            scroll.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                scroll.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }

        marginAdd(root, text("Agenda por Voz", 29, DARK, true), 3);
        marginAdd(root, text("Habla, revisa y guarda en tu Google Calendar.", 15, SUBTLE, false), 22);

        LinearLayout microphoneCard = vertical();
        microphoneCard.setPadding(dp(18), dp(20), dp(18), dp(18));
        microphoneCard.setBackground(rounded(Color.WHITE, 18, STROKE));
        marginAdd(microphoneCard, text("Crea un evento", 18, DARK, true), 13);
        Button speakButton = button("🎙  Hablar ahora", true);
        speakButton.setTextSize(19);
        speakButton.setMinHeight(dp(70));
        marginAdd(microphoneCard, speakButton, 16);
        speakButton.setOnClickListener(v -> startSpeech());
        label(microphoneCard, "Idioma del dictado");
        languageSpinner = spinner();
        setSpinnerOptions(languageSpinner, java.util.Arrays.asList("Español", "Català"));
        marginAdd(microphoneCard, languageSpinner, 14);
        marginAdd(microphoneCard, text("Ejemplo: «El jueves a las 10 tengo reunión con el proveedor. Avísame media hora antes».", 13, SUBTLE, false), 0);
        marginAdd(root, microphoneCard, 16);

        label(root, "Texto reconocido (también puedes escribirlo)");
        transcriptEdit = edit("Escribe o dicta aquí el evento...", 3);
        marginAdd(root, transcriptEdit, 10);
        Button interpretButton = button("Interpretar mensaje", false);
        interpretButton.setOnClickListener(v -> interpretText());
        marginAdd(root, interpretButton, 16);

        calendarAccessPanel = vertical();
        calendarAccessPanel.setPadding(dp(14), dp(13), dp(14), dp(13));
        calendarAccessPanel.setBackground(rounded(Color.rgb(241, 247, 243), 12, STROKE));
        calendarNotice = text("", 14, DARK, false);
        marginAdd(calendarAccessPanel, calendarNotice, 8);
        grantButton = button("Permitir acceso al calendario", false);
        grantButton.setOnClickListener(v -> {
            if (hasCalendarPermissions()) refreshCalendars();
            else requestCalendarPermissions();
        });
        marginAdd(calendarAccessPanel, grantButton, 0);
        marginAdd(root, calendarAccessPanel, 14);

        previewPanel = vertical();
        previewPanel.setVisibility(View.GONE);
        previewPanel.setPadding(dp(17), dp(18), dp(17), dp(18));
        previewPanel.setBackground(rounded(Color.WHITE, 18, STROKE));
        marginAdd(previewPanel, text("Revisa antes de guardar", 20, DARK, true), 5);
        marginAdd(previewPanel, text("Puedes modificar cualquiera de estos datos.", 13, SUBTLE, false), 15);
        noticeText = text("", 14, Color.rgb(143, 83, 9), false);
        noticeText.setPadding(dp(10), dp(9), dp(10), dp(9));
        noticeText.setBackground(rounded(Color.rgb(255, 248, 230), 9, 0));
        marginAdd(previewPanel, noticeText, 13);

        label(previewPanel, "Título del evento");
        titleEdit = edit("Nombre del evento", 1);
        marginAdd(previewPanel, titleEdit, 14);

        LinearLayout dateTimeRow = new LinearLayout(this);
        dateTimeRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout dateCell = vertical();
        LinearLayout timeCell = vertical();
        label(dateCell, "Fecha");
        label(timeCell, "Hora");
        dateButton = button("Seleccionar fecha", false);
        timeButton = button("Seleccionar hora", false);
        dateButton.setTextSize(14);
        timeButton.setTextSize(14);
        dateCell.addView(dateButton);
        timeCell.addView(timeButton);
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, -2, 1);
        left.rightMargin = dp(10);
        dateTimeRow.addView(dateCell, left);
        dateTimeRow.addView(timeCell, new LinearLayout.LayoutParams(0, -2, 1));
        marginAdd(previewPanel, dateTimeRow, 15);
        dateButton.setOnClickListener(v -> pickDate());
        timeButton.setOnClickListener(v -> pickTime());

        label(previewPanel, "Duración");
        durationSpinner = spinner();
        for (int duration : new int[]{15, 30, 45, 60, 90, 120, 180, 240}) durationOptions.add(duration);
        updateDurationOptions(60);
        marginAdd(previewPanel, durationSpinner, 14);

        label(previewPanel, "Avisarme antes");
        reminderSpinner = spinner();
        Collections.addAll(reminderOptions, -1, 0, 5, 10, 15, 30, 60, 120, 1440);
        updateReminderOptions(-1);
        marginAdd(previewPanel, reminderSpinner, 14);

        label(previewPanel, "Guardar en este Google Calendar");
        calendarSpinner = spinner();
        marginAdd(previewPanel, calendarSpinner, 14);

        label(previewPanel, "Notas (opcional)");
        descriptionEdit = edit("Añade detalles para el evento...", 3);
        marginAdd(previewPanel, descriptionEdit, 16);

        saveButton = button("✓  Confirmar y guardar", true);
        saveButton.setOnClickListener(v -> confirmSave());
        marginAdd(previewPanel, saveButton, 10);
        marginAdd(previewPanel, text("El evento no se guarda hasta pulsar este botón.", 12, SUBTLE, false), 0);
        marginAdd(root, previewPanel, 18);
        marginAdd(root, text("Sin registro ni claves externas. Google Calendar debe estar sincronizado en el teléfono.", 12, SUBTLE, false), 5);
    }

    private void startSpeech() {
        Intent voice = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        voice.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        voice.putExtra(RecognizerIntent.EXTRA_LANGUAGE,
                languageSpinner.getSelectedItemPosition() == 1 ? "ca-ES" : "es-ES");
        voice.putExtra(RecognizerIntent.EXTRA_PROMPT, "¿Qué evento quieres añadir?");
        voice.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try {
            startActivityForResult(voice, REQUEST_SPEECH);
        } catch (ActivityNotFoundException e) {
            new AlertDialog.Builder(this)
                    .setTitle("Reconocimiento de voz no disponible")
                    .setMessage("Este teléfono necesita un servicio de reconocimiento de voz compatible. Puedes escribir el evento en el cuadro de texto.")
                    .setPositiveButton("Entendido", null).show();
        }
    }

    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                transcriptEdit.setText(results.get(0));
                interpretText();
            }
        }
    }

    private void interpretText() {
        String spoken = transcriptEdit.getText().toString().trim();
        if (spoken.isEmpty()) {
            Toast.makeText(this, "Dicta o escribe un evento primero", Toast.LENGTH_LONG).show();
            return;
        }
        draft = EventParser.parse(spoken, LocalDateTime.now());
        chosenDate = draft.date;
        chosenTime = draft.time;
        dateConfirmed = draft.recognizedDate;
        timeConfirmed = draft.recognizedTime;
        titleEdit.setText(draft.title);
        descriptionEdit.setText("");
        updateDurationOptions(draft.durationMinutes);
        updateReminderOptions(draft.reminderMinutes);
        previewPanel.setVisibility(View.VISIBLE);
        updateDateTimeButtons();
        updateWarning();
        previewPanel.requestFocus();
        refreshCalendars();
    }

    private void updateDurationOptions(int selectedMinutes) {
        if (!durationOptions.contains(selectedMinutes)) durationOptions.add(selectedMinutes);
        Collections.sort(durationOptions);
        List<String> labels = new ArrayList<>();
        for (int mins : durationOptions) {
            labels.add(mins < 60 ? mins + " minutos" : mins % 60 == 0
                    ? mins / 60 + (mins == 60 ? " hora" : " horas")
                    : (mins / 60) + " h " + (mins % 60) + " min");
        }
        setSpinnerOptions(durationSpinner, labels);
        durationSpinner.setSelection(durationOptions.indexOf(selectedMinutes));
    }

    private void updateReminderOptions(int selectedMinutes) {
        if (!reminderOptions.contains(selectedMinutes)) reminderOptions.add(selectedMinutes);
        Collections.sort(reminderOptions);
        List<String> labels = new ArrayList<>();
        for (int minutes : reminderOptions) {
            if (minutes < 0) labels.add("Sin aviso");
            else if (minutes == 0) labels.add("Al empezar");
            else if (minutes >= 1440 && minutes % 1440 == 0) labels.add((minutes / 1440) + " día(s) antes");
            else if (minutes >= 60 && minutes % 60 == 0) labels.add((minutes / 60) + " hora(s) antes");
            else labels.add(minutes + " minutos antes");
        }
        setSpinnerOptions(reminderSpinner, labels);
        reminderSpinner.setSelection(reminderOptions.indexOf(selectedMinutes));
    }

    private void updateDateTimeButtons() {
        DateTimeFormatter dateFmt = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(new Locale("es", "ES"));
        dateButton.setText((dateConfirmed ? "" : "⚠ ") + chosenDate.format(dateFmt));
        timeButton.setText((timeConfirmed ? "" : "⚠ ") + chosenTime.format(DateTimeFormatter.ofPattern("HH:mm")));
    }
    private void updateWarning() {
        List<String> warnings = new ArrayList<>();
        if (!dateConfirmed) warnings.add("Selecciona una fecha: no se entendió en el audio.");
        if (!timeConfirmed) warnings.add("Selecciona una hora: no se entendió en el audio.");
        if (dateConfirmed && timeConfirmed && LocalDateTime.of(chosenDate, chosenTime).isBefore(LocalDateTime.now()))
            warnings.add("Atención: la fecha y hora están en el pasado.");
        noticeText.setVisibility(warnings.isEmpty() ? View.GONE : View.VISIBLE);
        noticeText.setText(android.text.TextUtils.join("\n", warnings));
    }
    private void pickDate() {
        DatePickerDialog picker = new DatePickerDialog(this,
                (view, year, month, day) -> {
                    chosenDate = LocalDate.of(year, month + 1, day);
                    dateConfirmed = true;
                    updateDateTimeButtons(); updateWarning();
                }, chosenDate.getYear(), chosenDate.getMonthValue() - 1, chosenDate.getDayOfMonth());
        picker.show();
    }
    private void pickTime() {
        TimePickerDialog picker = new TimePickerDialog(this,
                (view, hour, minute) -> {
                    chosenTime = LocalTime.of(hour, minute);
                    timeConfirmed = true;
                    updateDateTimeButtons(); updateWarning();
                }, chosenTime.getHour(), chosenTime.getMinute(), true);
        picker.show();
    }

    private boolean hasCalendarPermissions() {
        return checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED;
    }
    private void requestCalendarPermissions() {
        requestPermissions(new String[]{Manifest.permission.READ_CALENDAR,
                Manifest.permission.WRITE_CALENDAR}, REQUEST_CALENDAR_PERMISSION);
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CALENDAR_PERMISSION) refreshCalendars();
    }

    private void refreshCalendars() {
        if (!hasCalendarPermissions()) {
            calendarAccessPanel.setVisibility(View.VISIBLE);
            grantButton.setText("Permitir acceso al calendario");
            calendarNotice.setText("Para guardar eventos, permite el acceso al calendario del teléfono.");
            if (calendarSpinner != null) setSpinnerOptions(calendarSpinner, Collections.singletonList("Permiso pendiente"));
            return;
        }
        googleCalendars.clear();
        String[] cols = {CalendarContract.Calendars._ID,
                CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
                CalendarContract.Calendars.ACCOUNT_NAME,
                CalendarContract.Calendars.ACCOUNT_TYPE,
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
                CalendarContract.Calendars.SYNC_EVENTS,
                CalendarContract.Calendars.IS_PRIMARY};
        try (Cursor cursor = getContentResolver().query(CalendarContract.Calendars.CONTENT_URI,
                cols,
                CalendarContract.Calendars.ACCOUNT_TYPE + "=? AND " +
                        CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + ">=? AND " +
                        CalendarContract.Calendars.SYNC_EVENTS + "=1",
                new String[]{"com.google", String.valueOf(CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR)},
                null)) {
            if (cursor != null) while (cursor.moveToNext()) {
                long id = cursor.getLong(0);
                String label = cursor.getString(1);
                String email = cursor.getString(2);
                boolean primary = !cursor.isNull(6) && cursor.getInt(6) == 1;
                googleCalendars.add(new CalendarChoice(id,
                        (label == null || label.isEmpty() ? "Google Calendar" : label) + " · " + email, primary));
            }
        } catch (SecurityException e) {
            calendarNotice.setText("No hay permisos suficientes para acceder al calendario.");
            calendarAccessPanel.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            calendarNotice.setText("No se pudieron consultar los calendarios de Google.");
            calendarAccessPanel.setVisibility(View.VISIBLE);
        }
        googleCalendars.sort((a, b) -> Boolean.compare(b.primary, a.primary));
        if (googleCalendars.isEmpty()) {
            grantButton.setText("Volver a buscar calendarios");
            calendarAccessPanel.setVisibility(View.VISIBLE);
            calendarNotice.setText("No se ha encontrado ningún calendario Google editable y sincronizado. Comprueba que tu cuenta de Google está añadida y que Google Calendar tiene la sincronización activada.");
        } else {
            calendarAccessPanel.setVisibility(View.GONE);
        }
        if (calendarSpinner != null) {
            List<String> options = new ArrayList<>();
            for (CalendarChoice c : googleCalendars) options.add(c.label);
            if (options.isEmpty()) options.add("No hay calendarios de Google disponibles");
            setSpinnerOptions(calendarSpinner, options);
        }
    }

    private void confirmSave() {
        if (draft == null) return;
        if (!dateConfirmed || !timeConfirmed) {
            updateWarning();
            new AlertDialog.Builder(this).setTitle("Falta información")
                    .setMessage("Selecciona una fecha y una hora antes de guardar el evento.")
                    .setPositiveButton("Aceptar", null).show();
            return;
        }
        if (titleEdit.getText().toString().trim().isEmpty()) {
            titleEdit.setError("Escribe un título");
            return;
        }
        if (!hasCalendarPermissions()) {
            requestCalendarPermissions(); return;
        }
        if (googleCalendars.isEmpty()) {
            refreshCalendars();
            Toast.makeText(this, "No hay ningún calendario de Google disponible", Toast.LENGTH_LONG).show();
            return;
        }
        int idx = calendarSpinner.getSelectedItemPosition();
        if (idx < 0 || idx >= googleCalendars.size()) {
            Toast.makeText(this, "Selecciona un calendario", Toast.LENGTH_LONG).show(); return;
        }
        LocalDateTime start = LocalDateTime.of(chosenDate, chosenTime);
        int minutes = durationOptions.get(durationSpinner.getSelectedItemPosition());
        String message = "¿Guardar «" + titleEdit.getText().toString().trim() + "» el " +
                start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy 'a las' HH:mm")) +
                " (" + minutes + " minutos) en " + googleCalendars.get(idx).label + "?";
        if (start.isBefore(LocalDateTime.now())) message += "\n\nAtención: la fecha está en el pasado.";
        // Require explicit confirmation before creating the event.
        AlertDialog confirmation = new AlertDialog.Builder(this).setTitle("Confirmar evento")
                .setMessage(message).setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar ahora", (d, w) -> insertEvent()).create();
        confirmation.show();
    }

    private void insertEvent() {
        if (!hasCalendarPermissions() || !dateConfirmed || !timeConfirmed || googleCalendars.isEmpty()) return;
        int calendarIndex = calendarSpinner.getSelectedItemPosition();
        if (calendarIndex < 0 || calendarIndex >= googleCalendars.size()) return;
        saveButton.setEnabled(false);
        LocalDateTime start = LocalDateTime.of(chosenDate, chosenTime);
        int duration = durationOptions.get(durationSpinner.getSelectedItemPosition());
        int reminder = reminderOptions.get(reminderSpinner.getSelectedItemPosition());
        ZoneId zone = ZoneId.systemDefault();
        long startMillis = start.atZone(zone).toInstant().toEpochMilli();
        long endMillis = start.plusMinutes(duration).atZone(zone).toInstant().toEpochMilli();
        ContentValues values = new ContentValues();
        values.put(CalendarContract.Events.CALENDAR_ID, googleCalendars.get(calendarIndex).id);
        values.put(CalendarContract.Events.TITLE, titleEdit.getText().toString().trim());
        values.put(CalendarContract.Events.DESCRIPTION, descriptionEdit.getText().toString().trim());
        values.put(CalendarContract.Events.DTSTART, startMillis);
        values.put(CalendarContract.Events.DTEND, endMillis);
        values.put(CalendarContract.Events.EVENT_TIMEZONE, zone.getId());
        values.put(CalendarContract.Events.HAS_ALARM, reminder >= 0 ? 1 : 0);
        Uri created;
        try {
            created = getContentResolver().insert(CalendarContract.Events.CONTENT_URI, values);
            if (created == null) throw new IllegalStateException("El calendario no devolvió un identificador de evento");
        } catch (Exception e) {
            saveButton.setEnabled(true);
            new AlertDialog.Builder(this).setTitle("No se pudo guardar")
                    .setMessage("No se creó el evento. Comprueba los permisos y que el calendario elegido sea editable.\n\n" + e.getMessage())
                    .setPositiveButton("Aceptar", null).show();
            return;
        }

        boolean reminderSaved = true;
        if (reminder >= 0) {
            try {
                ContentValues alarm = new ContentValues();
                alarm.put(CalendarContract.Reminders.EVENT_ID, ContentUris.parseId(created));
                alarm.put(CalendarContract.Reminders.MINUTES, reminder);
                alarm.put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT);
                if (getContentResolver().insert(CalendarContract.Reminders.CONTENT_URI, alarm) == null)
                    reminderSaved = false;
            } catch (Exception e) {
                reminderSaved = false;
            }
        }
        Uri eventUri = created;
        String resultText = reminderSaved
                ? "El evento se ha añadido al calendario seleccionado. Se sincronizará con Google cuando el teléfono tenga conexión y la sincronización esté activa."
                : "El evento se ha guardado, pero no se pudo añadir el aviso. Abre Google Calendar y revisa el recordatorio.";
        previewPanel.setVisibility(View.GONE);
        transcriptEdit.setText("");
        draft = null;
        saveButton.setEnabled(true);
        new AlertDialog.Builder(this).setTitle(reminderSaved ? "Evento guardado" : "Evento guardado sin aviso")
                .setMessage(resultText)
                .setNegativeButton("Cerrar", null)
                .setPositiveButton("Ver evento", (dialog, which) -> {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, eventUri)); }
                    catch (ActivityNotFoundException e) {
                        Toast.makeText(this, "Abre Google Calendar para ver el evento", Toast.LENGTH_LONG).show();
                    }
                }).show();
    }
}
