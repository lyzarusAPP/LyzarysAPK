package com.coimbra.agendaporvoz;

import java.text.Normalizer;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Conservative, fully local Spanish/Catalan rules for event voice commands.
 * It never marks a date or time as understood unless a corresponding expression was matched.
 * The user must confirm the preview in MainActivity before insertion.
 */
public final class EventParser {
    public static final class Draft {
        public String spoken;
        public String title;
        public LocalDate date;
        public LocalTime time;
        public int durationMinutes = 60;
        public int reminderMinutes = -1;
        public boolean recognizedDate;
        public boolean recognizedTime;
        public boolean dateFromWeekday;
        public String warning = "";

        public LocalDateTime start() { return LocalDateTime.of(date, time); }
    }

    private static final Map<String, Integer> MONTHS = new HashMap<>();
    private static final Map<String, DayOfWeek> WEEKDAYS = new HashMap<>();
    private static final Map<String, Integer> NUMBER_WORDS = new HashMap<>();

    static {
        String[][] months = {
            {"enero", "gener"}, {"febrero", "febrer"}, {"marzo", "marc"},
            {"abril"}, {"mayo", "maig"}, {"junio", "juny"},
            {"julio", "juliol"}, {"agosto", "agost"},
            {"septiembre", "setiembre", "setembre"}, {"octubre"},
            {"noviembre", "novembre"}, {"diciembre", "desembre"}
        };
        for (int i = 0; i < months.length; i++) for (String m : months[i]) MONTHS.put(m, i + 1);
        String[][] weekdays = {
            {"lunes", "dilluns"}, {"martes", "dimarts"}, {"miercoles", "dimecres"},
            {"jueves", "dijous"}, {"viernes", "divendres"},
            {"sabado", "dissabte"}, {"domingo", "diumenge"}
        };
        for (int i = 0; i < weekdays.length; i++)
            for (String d : weekdays[i]) WEEKDAYS.put(d, DayOfWeek.of(i + 1));
        String[][] numbers = {
            {"cero", "zero"}, {"uno", "una", "un"}, {"dos", "dues"}, {"tres"},
            {"cuatro", "quatre"}, {"cinco", "cinc"}, {"seis", "sis"},
            {"siete", "set"}, {"ocho", "vuit"}, {"nueve", "nou"},
            {"diez", "deu"}, {"once", "onze"}, {"doce", "dotze"},
            {"trece", "tretze"}, {"catorce", "catorze"}, {"quince", "quinze"},
            {"dieciseis", "setze"}, {"diecisiete", "disset"},
            {"dieciocho", "divuit"}, {"diecinueve", "dinou"},
            {"veinte", "vint"}, {"treinta", "trenta"}
        };
        for (int i = 0; i < numbers.length; i++) for (String n : numbers[i]) NUMBER_WORDS.put(n, i);
    }

    private EventParser() {}

    private static String norm(String s) {
        return Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replace('’', '\'');
    }

    private static Matcher match(String input, String regex) {
        return Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE).matcher(input);
    }

    private static Integer number(String input) {
        if (input == null) return null;
        String s = norm(input).trim();
        if (s.matches("\\d{1,4}")) {
            try { return Integer.parseInt(s); } catch (NumberFormatException ignored) { return null; }
        }
        return NUMBER_WORDS.get(s);
    }

    public static Draft parse(String spoken, LocalDateTime now) {
        Draft d = new Draft();
        d.spoken = spoken == null ? "" : spoken.trim();
        String s = norm(d.spoken);
        LocalDate today = now.toLocalDate();
        d.date = today.plusDays(1); // a visible placeholder, NOT an inferred date
        d.time = LocalTime.of(9, 0); // a visible placeholder, NOT an inferred time

        parseDate(s, today, d);
        parseTime(s, d);
        if (d.dateFromWeekday && d.recognizedTime && d.date.equals(today)
                && !d.time.isAfter(now.toLocalTime())) d.date = d.date.plusWeeks(1);
        parseDuration(s, d);
        parseReminder(s, d);
        d.title = cleanTitle(d.spoken);
        if (d.title.isEmpty()) d.title = "Nuevo evento";

        if (d.recognizedDate && d.recognizedTime && !d.start().isAfter(now))
            d.warning = "La fecha y hora detectadas están en el pasado. Revísalas.";
        else if (!d.recognizedDate && !d.recognizedTime)
            d.warning = "No he identificado ni fecha ni hora. Elígelas antes de guardar.";
        else if (!d.recognizedDate)
            d.warning = "No he identificado la fecha. Selecciónala antes de guardar.";
        else if (!d.recognizedTime)
            d.warning = "No he identificado la hora. Selecciónala antes de guardar.";
        return d;
    }

    private static void parseDate(String s, LocalDate today, Draft d) {
        // "de la mañana" describes an hour; it must not turn "jueves" into tomorrow.
        s = s.replaceAll("\\b(?:de|por) la manana\\b", " ");
        Matcher m;
        // Relative dates in days/weeks/months.
        m = match(s, "\\b(?:dentro de|en|d'aqui a|daqui a)\\s+(\\d{1,3}|[a-z]+)\\s+(dias?|dies?|semanas?|setmanes?|meses?|mesos?)\\b");
        if (m.find()) {
            Integer n = number(m.group(1));
            if (n != null && n > 0 && n <= 365) {
                String unit = m.group(2);
                d.date = unit.startsWith("dia") || unit.startsWith("die") ? today.plusDays(n)
                        : unit.startsWith("sem") || unit.startsWith("setm") ? today.plusWeeks(n)
                        : today.plusMonths(n);
                d.recognizedDate = true;
                return;
            }
        }
        if (match(s, "\\b(pasado manana|dem[a]? passat|dema passat)\\b").find()) {
            d.date = today.plusDays(2);
            d.recognizedDate = true;
            return;
        }
        if (match(s, "\\b(manana|dema)\\b").find()) {
            d.date = today.plusDays(1);
            d.recognizedDate = true;
            return;
        }
        if (match(s, "\\b(hoy|avui)\\b").find()) {
            d.date = today;
            d.recognizedDate = true;
            return;
        }

        // Numeric date dd/mm[/yyyy], dd-mm or dd.mm.
        m = match(s, "(?<!\\d)(\\d{1,2})\\s*[/.-]\\s*(\\d{1,2})(?:\\s*[/.-]\\s*(\\d{2,4}))?(?!\\d)");
        if (m.find()) {
            try {
                int day = Integer.parseInt(m.group(1));
                int month = Integer.parseInt(m.group(2));
                int year = m.group(3) == null ? today.getYear() : Integer.parseInt(m.group(3));
                if (year < 100) year += 2000;
                LocalDate date = LocalDate.of(year, month, day);
                if (m.group(3) == null && date.isBefore(today)) date = date.plusYears(1);
                d.date = date;
                d.recognizedDate = true;
                return;
            } catch (RuntimeException ignored) { /* invalid: leave unresolved */ }
        }

        // "12 de noviembre", "12 novembre", "12 de noviembre de 2027".
        m = match(s, "\\b(?:el|dia|el dia)?\\s*(\\d{1,2})\\s*(?:de|d')?\\s*([a-z]+)(?:\\s+(?:de|del)\\s+(\\d{4}))?\\b");
        while (m.find()) {
            Integer month = MONTHS.get(m.group(2));
            if (month == null) continue;
            try {
                int day = Integer.parseInt(m.group(1));
                int year = m.group(3) != null ? Integer.parseInt(m.group(3)) : today.getYear();
                LocalDate date = LocalDate.of(year, month, day);
                if (m.group(3) == null && date.isBefore(today)) date = date.plusYears(1);
                d.date = date;
                d.recognizedDate = true;
                return;
            } catch (RuntimeException ignored) { /* invalid */ }
        }

        // "el jueves", "el próximo jueves", "jueves de la semana que viene".
        m = match(s, "\\b(lunes|dilluns|martes|dimarts|miercoles|dimecres|jueves|dijous|viernes|divendres|sabado|dissabte|domingo|diumenge)\\b");
        if (m.find()) {
            DayOfWeek day = WEEKDAYS.get(m.group(1));
            boolean nextWeek = match(s, "\\b(?:semana que viene|proxima semana|setmana que ve|setmana vinent)\\b").find();
            if (nextWeek) {
                LocalDate nextMonday = today.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
                d.date = nextMonday.plusDays(day.getValue() - 1L);
            } else {
                d.date = today.with(TemporalAdjusters.nextOrSame(day));
            }
            d.dateFromWeekday = true;
            d.recognizedDate = true;
        }
    }

    private static void parseTime(String s, Draft d) {
        Matcher m = match(s, "\\b(?:a las?|a les?|sobre las?|sobre les?)\\s*(\\d{1,2}|[a-z]+)\\s*(?::|\\s+y\\s+|\\s+i\\s+)(\\d{1,2}|media|mitja|cuarto|quart)\\b");
        if (m.find()) {
            Integer h = number(m.group(1));
            String part = m.group(2);
            Integer minute = part.equals("media") || part.equals("mitja") ? 30
                    : part.equals("cuarto") || part.equals("quart") ? 15 : number(part);
            if (setTime(h, minute, s, d)) return;
        }
        m = match(s, "\\b(?:a las?|a les?|sobre las?|sobre les?)\\s*(\\d{1,2}|[a-z]+)(?:\\s*(?:en punto|en punt))?\\b");
        if (m.find() && setTime(number(m.group(1)), 0, s, d)) return;
        // 10:30 when not prefixed by "a las".
        m = match(s, "(?<!\\d)(\\d{1,2}):(\\d{2})(?!\\d)");
        if (m.find()) setTime(number(m.group(1)), number(m.group(2)), s, d);
    }

    private static boolean setTime(Integer h, Integer minute, String s, Draft d) {
        if (h == null || minute == null || h > 23 || h < 0 || minute > 59 || minute < 0) return false;
        boolean pm = match(s, "\\b(?:de la tarde|de la noche|por la tarde|por la noche|del vespre|de la tarda|de la nit)\\b").find();
        boolean am = match(s, "\\b(?:de la manana|por la manana|del mati|al mati|de la matinada)\\b").find();
        if (pm && h >= 1 && h <= 11) h += 12;
        if (am && h == 12) h = 0;
        d.time = LocalTime.of(h, minute);
        d.recognizedTime = true;
        return true;
    }

    private static void parseDuration(String s, Draft d) {
        Matcher m = match(s, "\\b(?:durante|durant)\\s+(\\d+|[a-z]+)\\s+(horas?|hores?|minutos?|minuts?)\\b");
        if (m.find()) {
            Integer n = number(m.group(1));
            if (n != null && n > 0 && n <= 480) {
                d.durationMinutes = m.group(2).startsWith("hor") ? n * 60 : n;
                return;
            }
        }
        if (match(s, "\\b(?:durante|durant)\\s+(?:media hora|mitja hora)\\b").find()) {
            d.durationMinutes = 30;
            return;
        }
        if (match(s, "\\b(?:durante|durant)\\s+(?:hora y media|hora i mitja)\\b").find()) {
            d.durationMinutes = 90;
        }
    }

    private static void parseReminder(String s, Draft d) {
        if (!match(s, "\\b(?:avisa(?:me|m)|avisame|recuerda(?:me|m)|recuerdame|recorda(?:'m|m)|notifica(?:me|m)|avis)\\b").find()
                && !match(s, "\\b(?:recordatorio|avis|aviso)\\b").find()) return;
        Matcher m = match(s, "\\b(\\d{1,3}|[a-z]+)\\s*(minutos?|minuts?|horas?|hores?|dias?|dies?)\\s*(?:antes|abans)\\b");
        if (m.find()) {
            Integer n = number(m.group(1));
            if (n != null && n > 0 && n <= 1440) {
                String unit = m.group(2);
                int mins = unit.startsWith("hor") ? n * 60 : (unit.startsWith("dia") || unit.startsWith("die")) ? n * 1440 : n;
                d.reminderMinutes = mins;
                return;
            }
        }
        if (match(s, "\\b(?:media hora|mitja hora)\\s*(?:antes|abans)\\b").find())
            d.reminderMinutes = 30;
        else if (match(s, "\\b(?:una hora|un hora)\\s*(?:antes|abans)\\b").find())
            d.reminderMinutes = 60;
        else if (match(s, "\\b(?:un dia|una dia)\\s*(?:antes|abans)\\b").find())
            d.reminderMinutes = 1440;
    }

    private static String cleanTitle(String raw) {
        String title = raw == null ? "" : raw.trim();
        // Remove the alert clause, not the subject of the event.
        // Period-of-day qualifiers must go before removing the word "mañana".
        title = title.replaceAll("(?iU)\\b(?:de\\s+la|por\\s+la|del|al)\\s+(?:ma[ñn]ana|tarde|noche|mat[ií]|tarda|vespre|nit|matinada)\\b", " ");
        title = title.replaceAll("(?iU)[,;.]?\\s*(?:y\\s+)?(?:av[ií]same|avisam|recu[eé]rdame|recorda'm|recordam|pon\\s+un\\s+aviso|amb\\s+un\\s+av[ií]s)\\s+(?:con\\s+)?(?:\\d+|una?|media|mitja|quince|quinze|treinta|trenta)\\s*(?:minutos?|minuts?|horas?|hores?|d[ií]as?|dies?)?\\s*(?:antes|abans).*", "");
        title = title.replaceAll("(?iU)\\b(?:para\\s+)?(?:el\\s+)?(?:pasado\\s+ma[ñn]ana|dem[aà]\\s+passat|ma[ñn]ana|dem[aà]|hoy|avui)\\b", " ");
        title = title.replaceAll("(?iU)\\b(?:el|este|esta|pr[oó]ximo|pr[oò]xim|el\\s+pr[oó]ximo)?\\s*(?:lunes|martes|mi[eé]rcoles|jueves|viernes|s[aá]bado|domingo|dilluns|dimarts|dimecres|dijous|divendres|dissabte|diumenge)\\b(?:\\s+de\\s+la\\s+semana\\s+que\\s+viene|\\s+de\\s+la\\s+setmana\\s+que\\s+ve)?", " ");
        title = title.replaceAll("(?iU)\\b(?:el\\s+)?\\d{1,2}\\s*(?:de|d')?\\s*(?:enero|gener|febrero|febrer|marzo|mar[çc]|abril|mayo|maig|junio|juny|julio|juliol|agosto|agost|septiembre|setiembre|setembre|octubre|noviembre|novembre|diciembre|desembre)(?:\\s+de\\s+\\d{4})?\\b", " ");
        title = title.replaceAll("(?iU)\\b\\d{1,2}[/.-]\\d{1,2}(?:[/.-]\\d{2,4})?\\b", " ");
        title = title.replaceAll("(?iU)\\b(?:dentro\\s+de|d'aqu[ií]\\s+a|en)\\s+(?:\\d+|dos|tres|una?|dues)\\s+(?:d[ií]as?|dies?|semanas?|setmanes?|meses?|mesos?)\\b", " ");
        title = title.replaceAll("(?iU)\\b(?:a\\s+las?|a\\s+les?|sobre\\s+las?)\\s+(?:\\d{1,2}|diez|deu|once|onze|doce|dotze|nueve|nou|ocho|vuit|siete|set|seis|sis|cinco|cinc|cuatro|quatre|tres|dos|dues|una?)(?:\\s*(?::|y|i)\\s*(?:\\d{1,2}|media|mitja|cuarto|quart))?(?:\\s+en\\s+punto)?\\b", " ");
        title = title.replaceAll("(?iU)\\b\\d{1,2}:\\d{2}\\b", " ");
        title = title.replaceAll("(?iU)\\b(?:de\\s+la|por\\s+la|del|al)\\s+(?:ma[ñn]ana|tarde|noche|mat[ií]|tarda|vespre|nit|matinada)\\b", " ");
        title = title.replaceAll("(?iU)\\b(?:durante|durant)\\s+(?:\\d+|una?|media|mitja|hora\\s+y\\s+media)\\s*(?:horas?|hores?|minutos?|minuts?)?\\b", " ");
        title = title.replaceAll("(?iU)^\\s*(?:oye|ok\\s+google|por\\s+favor|sisplau)[,\\s]*", "");
        title = title.replaceAll("(?iU)^\\s*(?:crea(?:me)?|a[ñn]ade|apunta|programa|ponme|pon|agenda|crea'm|afegeix|apunta'm|recorda'm)\\s+(?:un\\s+)?(?:evento|cita|recordatorio|reuni[oó]n|esdeveniment)?\\s*(?:en|al|a)?\\s*(?:mi|el|meu)?\\s*(?:calendario|calendari|agenda)?\\s*(?:que|de|para)?\\s*", "");
        title = title.replaceAll("(?iU)^\\s*(?:recu[eé]rdame|recorda.m)\\s+que\\s+", "");
        title = title.replaceAll("(?iU)^\\s*(?:tengo\\s+que|tengo|tinc\\s+que|tinc|hay|hi ha|una|un)\\s+", "");
        title = title.replaceAll("^[\\s,.:;\\-]+|[\\s,.:;\\-]+$", "");
        title = title.replaceAll("\\s{2,}", " ").trim();
        if (title.length() > 120) title = title.substring(0, 120).trim();
        if (!title.isEmpty()) title = title.substring(0, 1).toUpperCase(Locale.ROOT) + title.substring(1);
        return title;
    }
}
