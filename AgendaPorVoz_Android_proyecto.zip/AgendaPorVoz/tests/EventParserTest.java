import com.coimbra.agendaporvoz.EventParser;
import java.time.*;

public class EventParserTest {
    private static final LocalDateTime NOW = LocalDateTime.of(2026, 11, 9, 9, 0); // Monday
    private static int count = 0;
    private static void eq(Object actual, Object expected, String name) {
        count++;
        if (!actual.equals(expected)) throw new AssertionError(name + ": expected " + expected + ", got " + actual);
    }
    private static void ok(boolean value, String name) {
        count++;
        if (!value) throw new AssertionError(name);
    }
    public static void main(String[] args) {
        EventParser.Draft a = EventParser.parse("El jueves a las 10 de la mañana tengo reunión con el proveedor chino, avísame media hora antes", NOW);
        eq(a.date, LocalDate.of(2026, 11, 12), "weekday");
        eq(a.time, LocalTime.of(10, 0), "morning");
        eq(a.reminderMinutes, 30, "half-hour notice");
        ok(a.title.toLowerCase().contains("proveedor chino"), "title preservation");
        EventParser.Draft b = EventParser.parse("Mañana a las 6 y media de la tarde cita con Mario", NOW);
        eq(b.date, LocalDate.of(2026, 11, 10), "tomorrow");
        eq(b.time, LocalTime.of(18, 30), "afternoon half");
        EventParser.Draft c = EventParser.parse("Demà a les 9:15 reunió de vendes", NOW);
        eq(c.date, LocalDate.of(2026, 11, 10), "catalan tomorrow");
        eq(c.time, LocalTime.of(9, 15), "catalan time");
        EventParser.Draft d = EventParser.parse("El 25 de desembre a les 12:00 dinar familiar", NOW);
        eq(d.date, LocalDate.of(2026, 12, 25), "Catalan december");
        eq(d.time, LocalTime.NOON, "noon");
        EventParser.Draft e = EventParser.parse("Dentista dentro de dos semanas a las 17:00 avísame 15 minutos antes", NOW);
        eq(e.date, LocalDate.of(2026, 11, 23), "relative weeks");
        eq(e.reminderMinutes, 15, "numeric reminder");
        EventParser.Draft f = EventParser.parse("Tengo que llamar al banco", NOW);
        ok(!f.recognizedDate && !f.recognizedTime, "unknown fields not inferred");
        EventParser.Draft g = EventParser.parse("Reunión 12/12/2026 a las 10", NOW);
        eq(g.date, LocalDate.of(2026, 12, 12), "full numeric date");
        eq(g.time, LocalTime.of(10, 0), "integer time");
        EventParser.Draft h = EventParser.parse("Reunión el martes de la semana que viene a las 11", NOW);
        eq(h.date, LocalDate.of(2026, 11, 17), "next week");
        EventParser.Draft i = EventParser.parse("El 30 de febrero a las 15 reunión imposible", NOW);
        ok(!i.recognizedDate, "invalid date should be unresolved");
        EventParser.Draft j = EventParser.parse("El lunes a las 10 revisar presupuestos", NOW);
        eq(j.date, LocalDate.of(2026, 11, 9), "weekday today future hour");
        EventParser.Draft k = EventParser.parse("El lunes a las 8 revisar presupuestos", NOW);
        eq(k.date, LocalDate.of(2026, 11, 16), "weekday today past hour");
        EventParser.Draft l = EventParser.parse("Pasado mañana a las 12:45 comer con Ana", NOW);
        eq(l.date, LocalDate.of(2026, 11, 11), "day after tomorrow");
        eq(l.time, LocalTime.of(12, 45), "time with 45");
        EventParser.Draft m = EventParser.parse("Avui a les deu del matí revisió mèdica", NOW);
        eq(m.date, LocalDate.of(2026, 11, 9), "catalan today");
        eq(m.time, LocalTime.of(10, 0), "catalan spoken number");
        EventParser.Draft n = EventParser.parse("Mañana a las 7 de la tarde reunión durante media hora", NOW);
        eq(n.durationMinutes, 30, "half hour duration");
        eq(n.time, LocalTime.of(19, 0), "afternoon numeric");
        EventParser.Draft o = EventParser.parse("Recuérdame que el viernes a las diez tengo que llamar a Juan", NOW);
        ok(!o.title.toLowerCase().contains("recuérdame"), "clean reminder wording");
        EventParser.Draft p = EventParser.parse("Dentista mañana a las 10, avísame un día antes", NOW);
        eq(p.reminderMinutes, 1440, "day reminder");
        System.out.println("OK: " + count + " assertions");
    }
}
