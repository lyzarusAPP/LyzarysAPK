#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p tests/out
javac -encoding UTF-8 -d tests/out app/src/main/java/com/coimbra/agendaporvoz/EventParser.java tests/EventParserTest.java
java -cp tests/out EventParserTest
