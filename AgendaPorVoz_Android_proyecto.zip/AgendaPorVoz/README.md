# Agenda por Voz — Android

Aplicación Android de voz a calendario. Proyecto **desarrollado como primera versión / prototipo**. Puedes dictar en español o catalán, corregir la interpretación y confirmar antes de guardar el evento en un calendario de Google sincronizado en el dispositivo.

## Funciones

- Botón grande **«Hablar ahora»** para dictar con el servicio de reconocimiento de voz instalado en Android.
- También permite introducir el texto manualmente, sin usar micrófono.
- Reconocimiento local de expresiones comunes de fecha y hora en castellano/catalán.
- Vista previa editable: título, fecha, hora, duración, aviso, calendario de destino y notas.
- Si no entiende una fecha o una hora, **obliga a seleccionar ese dato** antes de guardar.
- Solicita una **segunda confirmación** antes de crear el evento.
- Inserta el evento en el calendario de Google elegido mediante el proveedor de calendarios Android. Si está sincronizado, Google Calendar lo reflejará.
- Reconoce, entre otras frases: «mañana», «pasado mañana», «el jueves», «la semana que viene», «12/12/2026», «el 25 de diciembre», «dentro de dos semanas», «a las 10», «a las 6 y media de la tarde», «avísame 15 minutos antes».

## Requisitos

- Android 8.0 o posterior (API 26+).
- Cuenta de Google añadida al teléfono y calendario de Google con la sincronización activada.
- Un servicio compatible con el reconocimiento de voz Android (por ejemplo, servicios de Google). Puede necesitar conexión a Internet según cómo esté configurado.
- Permisos de Android para leer y escribir en el calendario.

## Crear el APK desde Android Studio

1. Descarga e instala **Android Studio** desde https://developer.android.com/studio.
2. Descomprime este ZIP y abre la carpeta **AgendaPorVoz** como proyecto en Android Studio (**File > Open**).
3. Si el programa solicita Gradle, utiliza **Gradle 8.9** y **JDK 17**. Instala la plataforma Android 35 y los SDK Build Tools que pida la sincronización.
4. Espera a que finalice la sincronización. El proyecto usa Android Gradle Plugin 8.7.3.
5. Abre **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. El APK de depuración generado estará en `app/build/outputs/apk/debug/app-debug.apk`.
7. Copia ese APK al teléfono, ábrelo e instala la aplicación. Android puede solicitar permiso para instalar aplicaciones de origen desconocido.
8. Abre «Agenda por Voz», concede permisos de calendario y comienza a dictar.

**Importante:** el archivo ZIP contiene el **código fuente**. **No contiene un APK compilado**. En el entorno donde se generó este proyecto no estaba instalado el Android SDK y no fue posible verificar la compilación ni probarlo en un dispositivo real.

## Compilación automática con GitHub Actions (alternativa)

Si alguien sube todos los archivos del proyecto a un repositorio de GitHub, la acción incluida `.github/workflows/crear-apk.yml` compila el APK. En GitHub: **Actions > Compilar APK Android > Run workflow**. Tras terminar, descargar el artefacto `AgendaPorVoz-APK` y extraer `app-debug.apk`. También necesita verificación funcional en un teléfono Android.

## Comprobaciones automatizadas

La lógica de extracción de fechas se ha probado con `tests/EventParserTest.java` y se puede volver a ejecutar mediante:

```sh
sh run_parser_tests.sh
```

Necesitas Java 17+ y `javac` para estas comprobaciones, pero no el SDK de Android. Estas pruebas **no sustituyen** una compilación del proyecto ni una prueba en el teléfono.

## Limitaciones conocidas de la primera versión

- La interpretación de voz emplea reglas locales y **no es una IA capaz de entender cualquier frase**. Antes de guardar, revisa fecha y hora, especialmente frases ambiguas, expresiones menos habituales o fechas pronunciadas de forma no estándar.
- El reconocimiento de audio lo realiza el servicio de dictado seleccionado por Android. Según ese proveedor, el audio puede procesarse en la nube. La aplicación en sí no envía el audio a un servidor propio.
- No solicita credenciales ni contraseña de Google. Utiliza los calendarios Google sincronizados en el dispositivo.
- La duración predeterminada es 60 minutos y el aviso predeterminado es «Sin aviso» cuando no se menciona ninguno.
- Si el usuario niega el permiso de calendario, puede dictar y revisar, pero no guardar hasta conceder el permiso.
- Esta versión no ofrece eventos recurrentes, invitados, ubicación, enlaces de videollamada, calendarios no Google ni detección de conflictos de agenda.
- Para crear eventos desde fuera de la aplicación, todavía no incluye widgets, accesos directos de voz ni activación en segundo plano.

## Privacidad

La app no tiene permiso de Internet propio, no almacena cuentas ni contraseñas y no envía eventos a ningún servidor propio. El acceso a Google Calendar se realiza a través del proveedor de calendario Android. El proveedor de reconocimiento de voz del sistema puede operar mediante Internet.

## Fuentes técnicas

- Android Calendar provider: https://developer.android.com/identity/providers/calendar-provider
- Android RecognizerIntent: https://developer.android.com/reference/android/speech/RecognizerIntent
- Compatibilidad Android Gradle Plugin 8.7: https://developer.android.com/build/releases/agp-8-7-0-release-notes
